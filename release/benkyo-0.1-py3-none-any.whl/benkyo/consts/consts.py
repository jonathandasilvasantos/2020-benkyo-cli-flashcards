entries = dict()
entries['benkyo_repository_folder_name'] = '.benkyo'
entries['benkyo_database_filename'] = 'flashcards.db'

entries['benkyo_reward'] = 0.3
entries['benkyo_penality'] = 0.3

entries['python_interpreter'] = 'python3'
