import click

@click.command()
def version():
    click.echo("Version: 0.1")
